#include <M5Unified.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "EEPROM.h"

void setup() {
  M5.begin();
  M5.Imu.init();
  EEPROM.begin(512);
  Serial.begin(115200);
  Serial.flush();
  M5.Lcd.fillScreen(BLACK);
}

long time_started = 0;

void start() {
  delay(1000 + (rand() % 5000));
  time_started = millis();
}

void new_record(long reaction_time) {
  EEPROM.writeLong(0, reaction_time);
  EEPROM.commit();
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.printf("New record");
  delay(1000);
}

void clear_record() {
  EEPROM.writeLong(0, 1000000000); // Sla een arbitrair hoge waarde op
  EEPROM.commit();
}

void reacted() {
  long current_time = millis();
  long reaction_time = current_time - time_started;
  if (reaction_time < EEPROM.readLong(0)) {
    new_record(reaction_time);
  }
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.printf("Reaction time: %i ms", reaction_time);
  delay(2000);
  M5.Lcd.fillScreen(BLACK);
  time_started = 0;
}

void loop() {
  M5.update();
  uint16_t color = (time_started == 0) ? RED : GREEN;
  M5.Lcd.fillRect(10, 10, 50, 50, color);
  if (time_started == 0) {
    start();
  } else if (M5.BtnA.wasPressed() && M5.BtnB.wasPressed()) {
    clear_record();
  } else if (M5.BtnA.wasPressed()) {
    reacted();
  }
}
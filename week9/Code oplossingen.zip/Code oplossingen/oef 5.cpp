#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

#define RECT_WIDTH 50
#define RECT_HEIGHT 30

void move_position(float, float);
void load_position();
void save_position();

uint16_t x = 0; uint8_t y = 0;
void loop() {
  M5.update();
  delay(20);
  
  float acc_x = 0, acc_y = 0, acc_z = 0;
  M5.Imu.getAccelData(&acc_x, &acc_y, &acc_z);
  move_position(acc_x, acc_y);
  if (M5.BtnA.wasPressed()) {
    save_position();
  } else if (M5.BtnB.wasPressed()) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    load_position();
  }  M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, red_color);
}

void save_position() {
  int address = 0;
  uint8_t lower_x = x % 256;
  uint8_t upper_x = x >> 8;

  EEPROM.writeByte(address, lower_x);
  address++;
  EEPROM.writeByte(address, upper_x);
  address++;
  EEPROM.writeByte(address, y);
  EEPROM.commit();
}
void load_position() {
  int address = 0;
  uint8_t lower_x = EEPROM.readByte(address);
  address++;
  uint8_t upper_x = EEPROM.readByte(address);
  address++;
  x = (upper_x << 8) | lower_x;
  y = EEPROM.readByte(address);
}

#define MIN_TILT 0.15
#define SPEED 3
void move_position(float acc_x, float acc_y) {
  if (acc_x > MIN_TILT) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x -= SPEED;
  } else if (acc_x < -MIN_TILT ) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x += SPEED;
  }
  if (acc_y > MIN_TILT) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    y += SPEED;
  } else if (acc_y < -MIN_TILT ) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    y -= SPEED;
  }

  if (x >= M5.Lcd.width() || x < SPEED) {
    x = 0;
  }
  if (y >= M5.Lcd.height() || y < SPEED) {
    y = 0;
  }
}
#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

#define RECT_WIDTH 50
#define RECT_HEIGHT 30

uint8_t x = 0, y = 0;

#define MIN_TILT 0.15
#define SPEED 3
void move_position(float acc_x, float acc_y) {
  if (acc_x > MIN_TILT) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x -= SPEED;
  } else if (acc_x < -MIN_TILT ) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x += SPEED;
  }
  if (acc_y > MIN_TILT) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    y += SPEED;
  } else if (acc_y < -MIN_TILT ) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    y -= SPEED;
  }

  if (x >= M5.Lcd.width()) {
    x = 0;
  }
  if (y >= M5.Lcd.height()) {
    y = 0;
  }
}

void loop() {
  M5.update();
  delay(20);
  
  float acc_x = 0, acc_y = 0, acc_z = 0;
  M5.Imu.getAccelData(&acc_x, &acc_y, &acc_z);
  move_position(acc_x, acc_y);
  M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, red_color);
}
#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

// Houdt bij wanneer er van rood naar groen werd gegaan
// Gelijk aan 0 -> timer nog niet gestart
// type is long, want millis() geeft een long terug
long time_started = 0;

void start() {  // Wacht minstens 1 seconde, plus een willekeurig (max 5) aantal seconden
  delay(1000 + (rand() % 5000));
  time_started = millis();
}

void reacted() {
  long current_time = millis();
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  // reactietijd = huidige tijd - tijd waarop de timer werd gestart
  M5.Lcd.printf("Reaction time: %i ms", current_time - time_started);  // Even wachten voor het scherm terug zwart wordt gemaakt
  delay(2000);
  M5.Lcd.fillScreen(BLACK);
  time_started = 0; // Reset timer
}

void loop() {
  M5.update();
  // Rood als timer nog niet is gestart, groen indien wel
  uint16_t color = (time_started == 0) ? RED : GREEN;
  M5.Lcd.fillRect(10, 10, 50, 50, color); // Teken ergens een rechthoek in de juiste kleur
  if (time_started == 0) {
    start(); // Er is nog geen timer gezet -> start een nieuwe timer
  } else if (M5.BtnA.wasPressed()) {
    reacted();
  }
}
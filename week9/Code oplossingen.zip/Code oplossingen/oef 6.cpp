#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

#define MAX_NR_OF_PIXELS 10
struct Pixel {
  uint8_t x, y;
  uint16_t c;
};

uint8_t nr_of_pixels = 0;
struct Pixel pixels[MAX_NR_OF_PIXELS];
int iterations = 0; // Aantal iteraties tot nieuwe pixel wordt getoond

void add_pixel() {
  if (nr_of_pixels >= MAX_NR_OF_PIXELS) {
    return;
  }
  iterations = 1;
  uint8_t rand_x = rand() % M5.Lcd.width();
  uint8_t rand_y = rand() % M5.Lcd.height();
  uint16_t rand_color = M5.Lcd.color565(rand() % 256, rand() % 256, rand() % 256);
  pixels[nr_of_pixels] = {.x = rand_x, .y = rand_y, .c = rand_color};
  nr_of_pixels++;
}
void display_pixels() {
  for (uint8_t i = 0; i < nr_of_pixels; i++) {
    struct Pixel p = pixels[i];
    M5.Lcd.drawPixel(p.x, p.y, p.c);
    M5.Lcd.drawPixel(p.x + 1, p.y, p.c);
    M5.Lcd.drawPixel(p.x, p.y + 1, p.c);
    M5.Lcd.drawPixel(p.x + 1, p.y + 1, p.c);
  }
}

void save_pixels() {
  int address = 0;
  EEPROM.writeByte(address, nr_of_pixels); address++;
  for (uint8_t i = 0; i < nr_of_pixels; i++) {
    struct Pixel p = pixels[i];
    EEPROM.writeByte(address, p.x); address++;
    EEPROM.writeByte(address, p.y); address++;
    EEPROM.writeUInt(address, p.c); address += sizeof(uint16_t);
  }
  EEPROM.commit();
}

void load_pixels() {
  int address = 0;
  nr_of_pixels = EEPROM.readByte(address); address++;
  for (uint8_t i = 0; i < nr_of_pixels; i++) {
    uint8_t x = EEPROM.readByte(address); address++;
    uint8_t y = EEPROM.readByte(address); address++;
    uint16_t c = EEPROM.readUInt(address); address += sizeof(uint16_t);
    pixels[i] = { .x = x, .y = y, .c = c};
  }
  M5.Lcd.fillScreen(black_color);
  display_pixels();
}

void loop() {
  M5.update();
  delay(2000);

  if (iterations == 0) {
    add_pixel();
  }

  if (M5.BtnA.wasPressed()) {
    save_pixels();
  } else if (M5.BtnB.wasPressed()) {
    load_pixels();
  }

  display_pixels();
  iterations--;
}
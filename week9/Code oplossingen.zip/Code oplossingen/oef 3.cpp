#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

#define RECT_WIDTH 50
#define RECT_HEIGHT 30

uint8_t x = 0, y = 0;
void loop() {
  M5.update();
  delay(20);
  if (M5.BtnA.wasPressed() && M5.BtnB.wasPressed()) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x = 0; y = 0;
  } else if (M5.BtnA.wasPressed()) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    x += 10;
  } else if (M5.BtnB.wasPressed()) {
    M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, black_color);
    y += 10;
  }
  if (x >= M5.Lcd.width()) {
    x = 0;
  }
  if (y >= M5.Lcd.height()) {
      y = 0;
  }
  M5.Lcd.fillRect(x, y, RECT_WIDTH, RECT_HEIGHT, red_color);
}
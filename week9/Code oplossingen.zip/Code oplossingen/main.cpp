#include <M5Unified.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "EEPROM.h"

// The setup routine runs once when M5StickC starts up
void setup() {
  
  // Initialize the M5StickC object
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);

  // Lcd display
  M5.Lcd.fillScreen(WHITE);
  delay(500);
  M5.Lcd.fillScreen(GREEN);
  delay(500);
  M5.Lcd.fillScreen(BLACK);
  delay(500);

  // Text print
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(0, 10);
  M5.Lcd.setTextColor(WHITE);
  M5.Lcd.setTextSize(1);
  M5.Lcd.printf("Display Test!");

  // Draw graphics
  delay(500);
  M5.Lcd.drawRect(15, 55, 50, 50, BLUE);
  M5.Lcd.fillRect(15, 55, 50, 50, BLUE);
  delay(500);
  M5.Lcd.drawCircle(40, 80, 30, RED);
  M5.Lcd.fillCircle(40, 80, 30, RED);
  delay(500);
}

// The loop routine keeps looping as long as the controller is on
void loop(){
  M5.update();
  M5.Lcd.setCursor(0, 0);
  M5.Lcd.fillScreen(rand());
  if (M5.BtnA.isPressed() && M5.BtnB.isPressed()) {
    M5.Lcd.printf("Both buttons pressed");
    delay(1000);
  } else if (M5.BtnA.isPressed()) {
    M5.Lcd.printf("Button A pressed");
    delay(1000);
  } else if (M5.BtnB.isPressed()) {
    M5.Lcd.printf("Button B pressed");
    delay(1000);
  }
  delay(1000);
}
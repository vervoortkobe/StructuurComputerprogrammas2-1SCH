#include <M5Unified.h>

#include <stdlib.h>
#include <stdint.h>
#include "EEPROM.h"

uint16_t black_color = M5.Lcd.color565(0, 0, 0);
uint16_t red_color = M5.Lcd.color565(255, 0, 0);

void setup() {
  M5.begin();
  M5.Imu.init();
  Serial.begin(115200);
  Serial.flush();
  EEPROM.begin(512);
  M5.Lcd.fillScreen(black_color);
}

// Houdt bij wanneer er van rood naar groen werd gegaan
// Gelijk aan 0 -> timer nog niet gestart
// type is long, want millis() geeft een long terug
long time_started = 0;

void start() {
  delay(1000 + (rand() % 5000));
  time_started = millis();
}

void new_record(long reaction_time) {
  EEPROM.writeByte(0, 42); // Getal 42 op adres 0 geeft aan dat er een record bestaat
  EEPROM.writeLong(1, reaction_time); // Record opgeslagen op adres 1
  EEPROM.commit();
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.printf("New record");
  delay(1000);
}

void clear_record() {
  EEPROM.writeByte(0, 0); // Record wissen -> getal 42 overschrijven met iets anders
  EEPROM.commit();
}

void reacted() {
  long current_time = millis();
  long reaction_time = current_time - time_started;
  if (EEPROM.readByte(0) == 42) {
    // Er bestaat een record
    if (reaction_time < EEPROM.readLong(1)) {
        // Reactietijd is lager dan het record
        new_record(reaction_time);
    }
  } else {
    // Record bestond nog niet, om wat voor reden dan ook
    new_record(reaction_time);
  }
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.printf("Reaction time: %i ms", reaction_time);
  delay(2000);
  M5.Lcd.fillScreen(BLACK);
  time_started = 0;
}

void loop() {
  M5.update();
  uint16_t color = (time_started == 0) ? RED : GREEN;
  M5.Lcd.fillRect(10, 10, 50, 50, color);
  if (time_started == 0) {
    start();
  } else if (M5.BtnA.wasPressed() && M5.BtnB.wasPressed()) {
    clear_record();
  } else if (M5.BtnA.wasPressed()) {
    reacted();
  }
}
#ifndef ENCODER_H
#define ENCODER_H

/************************
* Instruction Encoding
************************/

/*
> Single byte
Pop: 			00: Pop top of stack.
Primitive +: 	01: Pop the top two values on the stack, add them, and pushes the result.
Primitive -: 	02: Pop the top two values on the stack, substract them, and pushes the result.

> Double byte
PushArg: 	10 xx: Push the value of arg xx on the stack. xx is backward (0 is last argument)
PushTemp: 	11 xx: Push the value of temp xx on the stack.
StoreTemp: 	12 xx: Store the value on top of the stack into temp xx.
DefineTemp: 13 xx: Define the number of temps (xx) used in the method.
ReturnTop: 	14 xx: Return to caller's frame and pushes current top of stack to caller's stack, active function has xx args

> Many bytes
PushInt: 	20 xx xx xx xx (xx xx xx xx): Push the IntType constant encoded in the next 4/8 bytes on the stack.
Call: 		21 xx xx xx xx (xx xx xx xx): Call the function which pointer is encoded in the next 4/8 bytes 
*/

// Single byte
#define Pop (unsigned char) 0
#define Plus (unsigned char) 1
#define Sub (unsigned char) 2

// Double byte
#define PushArg (unsigned char) 10
#define PushTemp (unsigned char) 11
#define StoreTemp (unsigned char) 12
#define DefineTemps (unsigned char) 13
#define ReturnTop (unsigned char) 14

// Many bytes
#define PushInt (unsigned char) 20
#define Call (unsigned char) 21

/*********************
* Type definition
*********************/

// These macros define the IntType for 16-, 32- and 64-bit operating systems (OS).
// Checking which OS is being used is compiler-dependent.

// Windows...
#if _WIN32 || _WIN64
   #if _WIN64
     #define IntType long long
  #else
    #define IntType int
  #endif
#endif
// GCC/LLVM...
#if __GNUC__
  #if __x86_64__ || __ppc64__ || __aarch64__
    #define IntType long long
  #else
    #define IntType int
  #endif
#endif
// Rest of the world...
#ifndef IntType
	#error "Must define IntType, unsupported compiler non sense. Set IntType to long long or int depending on word size (64 -> long long, 32 & 16 -> int)"
#endif

// A function is a list of bytecode instructions.
typedef unsigned char * Function;

// FunctionBuffer is used to create a function.
#define FunctionBufferSize 200
typedef struct {
	int pos;
	unsigned char *buffer;
} FunctionBuffer;

/*********************
 * Function assembling
 *********************/

FunctionBuffer * createFunctionBuffer();
Function * assemble(FunctionBuffer *fbuffer);
void pop(FunctionBuffer *fbuffer);
void plus(FunctionBuffer *fbuffer);
void sub(FunctionBuffer *fbuffer);
void pushArg(FunctionBuffer *fbuffer, unsigned char argIndex);
void pushTemp(FunctionBuffer *fbuffer, unsigned char tempIndex);
void storeTemp(FunctionBuffer *fbuffer, unsigned char tempIndex);
void defineTemps(FunctionBuffer *fbuffer, unsigned char numTemps);
void returnTop(FunctionBuffer *fbuffer, unsigned char numArgs);
void returnTop0(FunctionBuffer *fbuffer);
void pushInt(FunctionBuffer *fbuffer, IntType theConstant);
void call(FunctionBuffer *fbuffer, Function * function);
void sourcePointer(FunctionBuffer *fbuffer, char * sourcePointer);
void printFunction(Function *function);

#endif

//
//  pi.c
//  circle_example
//
//  Created by Elisa Gonzalez Boix on 24/09/15.
//  Copyright (c) 2015 Elisa Gonzalez Boix. All rights reserved.
//
//  Example from Dirk Derrider Struct 2

#include "pi.h"

double pi = 3.14;

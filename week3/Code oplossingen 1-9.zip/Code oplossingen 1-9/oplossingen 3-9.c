#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/************************************************************************************************************
 *                                                Oefening 3                                                *
 ************************************************************************************************************/

void fizzbuzz(int n) {
	int i = 1;
	while (i < n) {
		if (i % 3 == 0 && i % 5 == 0) {
			printf("%i: FizzBuzz\n", i);
		} else if (i % 3 == 0) {
			printf("%i: Fizz\n", i);
		} else if (i % 5 == 0) {
			printf("%i: Buzz\n", i);
		}
		i++;
	}
}

/************************************************************************************************************
 *                                                Oefening 4                                                *
 ************************************************************************************************************/

int fac(int n) {
	int result = 1;
	while (n > 1) {
		result *= n;
		n--;
	}
	return result;
}

double calc_cosine(double x, int n) {
	double result = 0;
	for (int i = 1; i <= n; i++) {
		int exponent = (i - 1) * 2;
		double numerator = pow(x, exponent);
		int denominator = fac(exponent);
		double term = numerator / denominator;
		if (i % 2 == 0) {
			result -= term; // result = result - term
		} else {
			result += term; // result = result + term
		}
	}
	return result;
}

/************************************************************************************************************
 *                                                Oefening 5                                                *
 ************************************************************************************************************/

void print_spaces(int n) {
	while (n-- > 0) {
		printf(" ");
	}
}

void print_stars(int n) {
	while (n-- > 0) {
		printf("*");
	}
}

void print_christmas_tree(int n) {
	int i = 1;
	while (i <= n) {
		print_spaces(n - i);
		print_stars(i * 2 - 1);
		printf("\n");
		i++;
	}
	int j = 0;
	while (j < 2) {
		print_spaces(n - 1);
		printf("*\n");
		j++;
	}
}

/************************************************************************************************************
 *                                                Oefening 6                                                *
 ************************************************************************************************************/

void print_primes(int x) {
	int i = 2;
	while(i < x) {
		// loop over alle getallen van 2 tot x
		int prime = 1;
		// prime == 1 -> i is een priemgetal
		// ga er eerst van uit dat i inderdaad priem is
		int j = 2;
		while (j < i) {
			// zoek een getal waardoor i deelbaar is
			if (i % j == 0) {
				// i deelbaar door j, dus toch niet priem
				prime = 0;
			}
			j++;
		}
		if (prime) {
			printf("%i\n", i);
		}
		i++;
	}
}

/************************************************************************************************************
 *                                                Oefening 7                                                *
 ************************************************************************************************************/

// Zie WPO week 4

/************************************************************************************************************
 *                                                Oefening 8                                                *
 ************************************************************************************************************/

int convert_hex_to_dec(char hex[]) {
	int length = strlen(hex);
	int i = length - 1;
	int number = 0;
	int power_of_sixteen = 1;
	while (i >= 0) {
		char c = hex[i];
		int digit = 0;

		/*
		 * Hier heb je enkele mogelijkheden om een hexadecimaal karakter om te zetten naar een cijfer.
		 * Een eerste mogelijkheid is een grote if met 16 takken, waarbij je in elke conditie controleert
		 * of het karakter overeenkomt met '0', met '1', enz.:
		 * if (c == '0') {
		 *   digit = 0;
		 * } else if (c == '1') {
		 *   digit == 1;
		 * }
		 * ...
		 * Met een switch-statement over c zou je hetzelfde kunnen bereiken met minder lijnen code:
		 * switch (c) {
		 *   case '0': digit = 0; break;
		 *   case '1': digit = 1; break;
		 *   ...
		 * }
		 * De meest minimale manier is echter om gebruik te maken van het feit dat karakters
		 * voorgesteld worden als getallen (meer bepaald als de ASCII waarde van dat getal).
		 * Je kan dan ook wiskundige operaties toepassen op karakters, net zoals je dat kan doen op getallen.
		 * Bovendien volgen de ASCII waarden van de karakters '0' - '9' elkaar op, net zoals 'a'-'z' en 'A'-'Z'.
		 * 'a'-'z' en 'A'-'Z' staan echter niet vlak na '0'-'9' in de ASCII tabel.
		 */
		if (('0' <= c) && (c <= '9')) {
			// Het karakter c is een karakter tussen '0' en '9'.
			digit = c - '0';
		} else if (('A' <= c) && (c <= 'F')) {
			// Het karakter c is een karakter tussen 'A' en 'F'.
			digit = c - 'A' + 10; // 'A' komt overeen met 10.
		} else if (('a' <= c) && (c <= 'f')) {
			// Hoofdletters en kleine letters moeten apart behandeld worden
			digit = c - 'a' + 10;
		}

		// digit_number = het getal dat voorgesteld wordt door dat cijfer, rekening houdend met de positie van het cijfer
		int digit_number = digit * power_of_sixteen;
		number = number + digit_number;
		power_of_sixteen = power_of_sixteen * 16;
		i--;
	}
	return number;
}


/************************************************************************************************************
 *                                                Oefening 9                                                *
 ************************************************************************************************************/

void insertion_sort(char string[]) {
	int length = strlen(string);
	int outer_index = 1;
	while (outer_index < length) {
		int inner_index = outer_index;
		while (inner_index > 0 && string[inner_index - 1] >= string[inner_index]) {
			char temp = string[inner_index - 1];
			string[inner_index - 1] = string[inner_index];
			string[inner_index] = temp;
			inner_index--;
		}
		outer_index++;
	}
}

int main() {
	/* Oef 1 en 2 */
	// Zie makefile_oef_1 en makefile_oef_2
	// Denk eraan om deze bestanden te hernoemen naar "makefile" als je ze wil uittesten.

	/* Oef 3 */
	printf("Oef 3\n");
	fizzbuzz(20);

	/* Oef 4 */
	printf("\n\nOef 4\n");
	printf("De cosinus van %g is ongeveer %g\n", 3.1416, calc_cosine(3.1416, 5));
	printf("De cosinus van %g is ongeveer %g\n", 1.5708, calc_cosine(1.5708, 3));

	/* Oef 5 */
	printf("\n\nOef 5\n");
	print_christmas_tree(5);

	/* Oef 6 */
	printf("\n\nOef 6\n");
	print_primes(100);

	/* Oef 7 */
	printf("\n\nOef 7\n");
	printf("Zie WPO week 4\n");

	/* Oef 8 */
	printf("\n\nOef 8\n");
	char s[] = "A1";
	printf("%i\n", convert_hex_to_dec(s));

	/* Oef 9 */
	printf("\n\nOef 9\n");
	char s2[] = "randomstring";
	insertion_sort(s2);
	printf("%s\n", s2);

	return EXIT_SUCCESS;
}

